Dudka Font
=======================

This download contains six Dimkin static fonts:

  Dudka thin.ttf
  Dudka thin italic.ttf
  Dudka regular.ttf
  Dudka regular italic.ttf
  Dudka bold.ttf
  Dudka bold italic.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
